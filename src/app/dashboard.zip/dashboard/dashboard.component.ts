import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as Chartist from 'chartist';
declare var RadialGauge: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
    sensors = ['temperature', 'humidity', 'hydrogen', 'oxymeter', 'voltage'];
    voltageGauge: any;
    latestData: { [key: string]: any } = {};
    historicalData: any[] = [];
    selectedSensor: string | null = null;

  constructor(private http: HttpClient) { }
  ngOnInit() {
    this.sensors.forEach(sensor => {
      // Fetch latest reading
      this.http.get<{ timestamp: string, sensor_reading: number, serial_no: string }>(
        `http://localhost:5000/api/${sensor}/latest`
      ).subscribe({
        next: data => {
          this.latestData[sensor] = data;
          if (sensor === 'voltage') {
            if (!this.voltageGauge) {
              this.initializeVoltageGauge(data.sensor_reading);
              setInterval(() => {
              this.http.get<{ sensor_reading: number }>('http://localhost:5000/api/voltage/latest')
                .subscribe(res => {
                  if (this.voltageGauge) {
                    this.voltageGauge.value = res.sensor_reading;
                  }
                });
            }, 5000);
            } else {
              this.voltageGauge.value = data.sensor_reading;
            }
          }
        },
        error: () => {
          this.latestData[sensor] = { sensor_reading: '--', timestamp: '', serial_no: '' };
        }
      });

      // Fetch chart history and create chart
      this.http.get<{ timestamp: string, sensor_reading: number }[]>(
        `http://localhost:5000/api/${sensor}/history`
      ).subscribe(data => {
        const labels = data.map(d => d.timestamp);
        const values = data.map(d => d.sensor_reading);

        const chartData = {
          labels: labels,
          series: [values]
        };

        const chartOptions = {
          lineSmooth: Chartist.Interpolation.cardinal({ tension: 0 }),
          low: 0,
          showArea: true,
          fullWidth: true,
          chartPadding: { top: 20, right: 20, bottom: 40, left: 20 },
          axisX: {
            labelInterpolationFnc: function (value, index) {
              return index % 2 === 0 ? value : null;
            },
            offset: 40,
            showGrid: true
          },
          axisY: {
            offset: 40
          }
        };


        const chartId = `#${sensor}Chart`;
        const chart = new Chartist.Line(chartId, chartData, chartOptions);
        this.startAnimationForLineChart(chart);
      });
    });
  }
  initializeVoltageGauge(initialValue: number) {
    this.voltageGauge = new RadialGauge({
      renderTo: 'voltageGauge',
      width: 200,
      height: 200,
      units: "V",
      title: "Voltage",
      minValue: 0,
      maxValue: 400,
      majorTicks: ["0", "50", "100", "150","200", "250","300","350","400"],
      minorTicks: 5,
      strokeTicks: true,
      highlights: [
        { from: 0, to: 200, color: "rgba(0, 100, 0, 0.89)" },
        { from: 200, to: 300, color: "rgba(255, 166, 0, 0.98)" },
        { from: 300, to: 400, color: "rgb(255, 0, 0)" }
      ],
      colorPlate: "#fff",
      colorMajorTicks: "#000",
      colorMinorTicks: "#222",
      colorTitle: "#000",
      colorUnits: "#000",
      colorNumbers: "#000",
      colorNeedle: "rgba(200, 50, 50, 1)",
      colorNeedleEnd: "rgba(255, 50, 50, .9)",
      needleType: "arrow",
      needleWidth: 2,
      needleCircleSize: 7,
      needleCircleOuter: true,
      needleCircleInner: false,
      valueBox: true,
      animationDuration: 1500,
      animationRule: "linear",
      borders: false,
      borderShadowWidth: 0,
      value: initialValue
    }).draw();
  }

  showHistory(sensor: string) {
    this.selectedSensor = sensor;
    const latestTimestamp = this.latestData[sensor]?.timestamp;

    this.http.get<any[]>(`http://localhost:5000/api/${sensor}/history`).subscribe({
      next: data => {
        // Filter out latest to avoid duplication
        this.historicalData = data.filter(d => d.timestamp !== latestTimestamp);
      },
      error: err => {
        console.error(`Error fetching history for ${sensor}:`, err);
        this.historicalData = [];
      }
    });
  }

  closeHistory() {
    this.selectedSensor = null;
    this.historicalData = [];
  }

  startAnimationForLineChart(chart) {
      let seq = 0;
    const delays = 80, durations = 500;

    chart.on('draw', function (data: any) {
      if (data.type === 'line' || data.type === 'area') {
        data.element.animate({
          d: {
            begin: 600,
            dur: 700,
            from: data.path.clone().scale(1, 0).translate(0, data.chartRect.height()).stringify(),
            to: data.path.clone().stringify(),
            easing: Chartist.Svg.Easing.easeOutQuint
          }
        });
      } else if (data.type === 'point') {
        seq++;
        data.element.animate({
          opacity: {
            begin: seq * delays,
            dur: durations,
            from: 0,
            to: 1,
            easing: 'ease'
          }
        });
      }
    });

    seq = 0;
  }
  getCardHeaderClass(sensor: string): string {
    switch (sensor) {
      case 'temperature': return 'card-header-warning';
      case 'humidity': return 'card-header-success';
      case 'oxymeter': return 'card-header-danger';
      case 'hydrogen': return 'card-header-info';
      default: return 'card-header-primary';
    }
  }

  getSensorIcon(sensor: string): string {
    switch (sensor) {
      case 'temperature': return 'thermostat';
      case 'humidity': return 'water_drop';
      case 'oxymeter': return 'favorite';
      case 'hydrogen': return 'science';
      default: return 'sensors';
    }
  }
  }
 /*
  startAnimationForBarChart(chart){
      let seq2: any, delays2: any, durations2: any;

      seq2 = 0;
      delays2 = 80;
      durations2 = 500;
      chart.on('draw', function(data) {
        if(data.type === 'bar'){
            seq2++;
            data.element.animate({
              opacity: {
                begin: seq2 * delays2,
                dur: durations2,
                from: 0,
                to: 1,
                easing: 'ease'
              }
            });
        }
      });

      seq2 = 0;
  };
  ngOnInit() {
      /* ----------==========     Daily Sales Chart initialization For Documentation    ==========---------- */
      /*
      const dataDailySalesChart: any = {
          labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
          series: [
              [12, 17, 7, 17, 23, 18, 38]
          ]
      };

     const optionsDailySalesChart: any = {
          lineSmooth: Chartist.Interpolation.cardinal({
              tension: 0
          }),
          low: 0,
          high: 50, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
          chartPadding: { top: 0, right: 0, bottom: 0, left: 0},
      }

      var dailySalesChart = new Chartist.Line('#dailySalesChart', dataDailySalesChart, optionsDailySalesChart);

      this.startAnimationForLineChart(dailySalesChart);


      /* ----------==========     Completed Tasks Chart initialization    ==========---------- */
      /*
      const dataCompletedTasksChart: any = {
          labels: ['12p', '3p', '6p', '9p', '12p', '3a', '6a', '9a'],
          series: [
              [230, 750, 450, 300, 280, 240, 200, 190]
          ]
      };

     const optionsCompletedTasksChart: any = {
          lineSmooth: Chartist.Interpolation.cardinal({
              tension: 0
          }),
          low: 0,
          high: 1000, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
          chartPadding: { top: 0, right: 0, bottom: 0, left: 0}
      }

      var completedTasksChart = new Chartist.Line('#completedTasksChart', dataCompletedTasksChart, optionsCompletedTasksChart);

      // start animation for the Completed Tasks Chart - Line Chart
      this.startAnimationForLineChart(completedTasksChart);



      /* ----------==========     Emails Subscription Chart initialization    ==========---------- */
      /*
      var datawebsiteViewsChart = {
        labels: ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'],
        series: [
          [542, 443, 320, 780, 553, 453, 326, 434, 568, 610, 756, 895]

        ]
      };
      var optionswebsiteViewsChart = {
          axisX: {
              showGrid: false
          },
          low: 0,
          high: 1000,
          chartPadding: { top: 0, right: 5, bottom: 0, left: 0}
      };
      var responsiveOptions: any[] = [
        ['screen and (max-width: 640px)', {
          seriesBarDistance: 5,
          axisX: {
            labelInterpolationFnc: function (value) {
              return value[0];
            }
          }
        }]
      ];
      var websiteViewsChart = new Chartist.Bar('#websiteViewsChart', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

      //start animation for the Emails Subscription Chart
      this.startAnimationForBarChart(websiteViewsChart);
  }
  */


